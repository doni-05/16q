package com.example.otkritka

import android.os.Bundle
import android.view.Surface
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.otkritka.ui.theme.OtkritkaTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            OtkritkaTheme {  }
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    Box(modifier = Modifier.fillMaxSize()) {
                        // Фоновое изображение
                        Image(
                            painter = painterResource(id = R.drawable.qwerty),
                            contentDescription = "Background Image",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop // Масштабирование изображения, чтобы оно заполнило всю область
                        )

                        Otkritka(
                            message = "С Днём Победы!",
                            from = "От  Диербёка",
                            modifier = Modifier.padding(8.dp)
                        )
                    }
                }
            }
        }
    }


@Composable
fun Otkritka(message: String, from: String, modifier: Modifier = Modifier) {
    Column(
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
    ) {

        Text(
            text = message,
            fontSize = 70.sp,
            lineHeight = 116.sp,
            fontStyle = FontStyle.Italic,
            color =Color.Red,
            textAlign = TextAlign.Center
        )
        Image(
            painter = painterResource(id = R.drawable.qwerty),
            contentDescription = "New Year Image",
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
        )
        Text(
            text = from,
            fontSize = 36.sp,
            fontStyle = FontStyle.Italic,
            color =Color.Red,

            modifier = Modifier
                .padding(16.dp)
                .align(alignment = Alignment.End)
        )
    }
}

@Preview(showBackground = true)
@Composable
fun OtkritkaPreview() {
    OtkritkaTheme {
        Otkritka(message = "С Днём Победы!", from = "От Диербека")
    }
}
