package com.example.pr16_boboev_e
import android.content.Intent
import android.os.Bundle
import android.service.autofill.Validators.or
import android.view.View
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class login : AppCompatActivity() {

    private lateinit var emailEditText: EditText
    private lateinit var passwordEditText: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.login)
        emailEditText=findViewById(R.id.editTextNumberPassword)
        passwordEditText=findViewById(R.id.editTextNumberPassword)
    }
    fun onTextButtonClick(view: View) {
        // Обработка нажатия на текстовую кнопку
        val intent = Intent(this, SecondActivity::class.java)
        startActivity(intent)
    }
    fun sign_in(view: View){
      val email=emailEditText.text.toString()
        val password=passwordEditText.text.toString()
        if (email.isEmpty() || password.isEmpty()){
            Toast.makeText(this, "email или пароль пустой", Toast.LENGTH_SHORT).show()

        }
        else{
            val intent = Intent(this, main::class.java)
            startActivity(intent)

        }
    }
}