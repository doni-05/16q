package com.example.pr16_boboev_e

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class profile : AppCompatActivity() {

    private val REQUEST_CAMERA_PERMISSION = 200
    private val REQUEST_IMAGE_CAPTURE = 1
    private val REQUEST_PHOTO_ACTIVITY = 2

    private lateinit var imageView14: ImageView
    private lateinit var imageButton14: ImageButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.profile)

        imageView14 = findViewById(R.id.imageView14)
        imageButton14 = findViewById(R.id.imageView14)

        imageButton14.setOnClickListener {
            // Проверяем, есть ли у нас разрешение на использование камеры
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
                // Если разрешения нет, запрашиваем его
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE),
                    REQUEST_CAMERA_PERMISSION
                )
            } else {
                // Если разрешение есть, открываем камеру
                openCamera()
            }
        }
    }

    private fun openCamera() {
        val takePictureIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        if (takePictureIntent.resolveActivity(packageManager) != null) {
            startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CAMERA_PERMISSION) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Разрешение получено, открываем камеру
                openCamera()
            } else {
                // Разрешение не получено, показываем сообщение пользователю
                Toast.makeText(this, "Camera permission denied", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            val extras = data?.extras
            val imageBitmap = extras?.get("data") as Bitmap
            imageView14.setImageBitmap(imageBitmap)
        } else if (requestCode == REQUEST_PHOTO_ACTIVITY) {
            if (resultCode == RESULT_OK) {
                val deletedImageUri = data?.getStringExtra("deletedImageUri")
                if (deletedImageUri != null) {
                    // Удаляем выбранную фотографию из ImageView в profile
                    imageView14.setImageDrawable(null)
                }
            }
        }
    }

    fun ibutton(view: View) {
        val imageUri = Uri.parse("android.resource://com.example.pr16_boboev_e/drawable/uknown1")
        val intent = Intent(this, PhotoActivity::class.java)
        intent.putExtra("imageUri", imageUri.toString())
        startActivityForResult(intent, REQUEST_PHOTO_ACTIVITY)
    }

    fun ibutton1(view: View) {
        val imageUri = Uri.parse("android.resource://com.example.pr16_boboev_e/drawable/unknown6")
        val intent = Intent(this, PhotoActivity::class.java)
        intent.putExtra("imageUri", imageUri.toString())
        startActivityForResult(intent, REQUEST_PHOTO_ACTIVITY)
    }

    fun ibutton2(view: View) {
        val imageUri = Uri.parse("android.resource://com.example.pr16_boboev_e/drawable/sunset")
        val intent = Intent(this, PhotoActivity::class.java)
        intent.putExtra("imageUri", imageUri.toString())
        startActivityForResult(intent, REQUEST_PHOTO_ACTIVITY)
    }

    fun ibutto3(view: View) {
        val imageUri = Uri.parse("android.resource://com.example.pr16_boboev_e/drawable/unknown")
        val intent = Intent(this, PhotoActivity::class.java)
        intent.putExtra("imageUri", imageUri.toString())
        startActivityForResult(intent, REQUEST_PHOTO_ACTIVITY)
    }
}